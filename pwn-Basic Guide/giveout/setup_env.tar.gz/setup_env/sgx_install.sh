apt-get update && apt-get install -y gnupg wget build-essential docker-compose

echo 'deb [arch=amd64] https://download.01.org/intel-sgx/sgx_repo/ubuntu bionic main' > /etc/apt/sources.list.d/intel-sgx.list
wget -qO - https://download.01.org/intel-sgx/sgx_repo/ubuntu/intel-sgx-deb.key | apt-key add -
apt-get update 

mkdir -p "/lib/modules/"`uname -r`"/kernel/drivers/intel/sgx"    
cp isgx.ko "/lib/modules/"`uname -r`"/kernel/drivers/intel/sgx"    
sh -c "cat /etc/modules | grep -Fxq isgx || echo isgx >> /etc/modules"    
/sbin/depmod
/sbin/modprobe isgx

mkdir /opt/intel/
chmod +x sgx_linux_x64_sdk_2.17.101.1.bin
cp sgx_linux_x64_sdk_2.17.101.1.bin /opt/intel/
cd /opt/intel/ && echo 'yes' | ./sgx_linux_x64_sdk_2.17.101.1.bin

apt-get install -y libcurl4 libprotobuf10 libssl1.1 make module-init-tools libsgx-aesm-launch-plugin
apt-get install -y --no-install-recommends libsgx-launch libsgx-urts

cd /opt/intel/sgx-aesm-service/aesm && LD_LIBRARY_PATH=. ./aesm_service --no-daemon &
