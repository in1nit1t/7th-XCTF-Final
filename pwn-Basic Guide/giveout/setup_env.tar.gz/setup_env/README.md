Before running the attachment, please make sure that the CPU of your machine is made by **Intel** and supports *Software Guard Extensions* (**SGX**).

You can check whether the current CPU supports/enables SGX by typing `cpuid | grep -i sgx` . If the output is similar to the following, then you don't need to worry about hardware issues.

```bash
      SGX: Software Guard Extensions supported = true
      SGX_LC: SGX launch config supported      = true
   SGX capability (0x12/0):
      SGX1 supported                         = true
      SGX2 supported                         = true
```

You can also search whether your CPU supports SGX on the [Intel website](https://ark.intel.com/content/www/us/en/ark/search/featurefilter.html?productType=873).

If your machine does not support SGX, it is recommended to rent a cloud server to run this game. Alibaba Cloud, Tencent Cloud, etc. can create instances with SGX features.

After solving the hardware support problem, execute `sgx_install.sh` to install the local environment consistent with the deployment environment of the game.

Have a good time :-)

------

**Note**: The operating system used in the deployment environment is **Ubuntu 18.04**.